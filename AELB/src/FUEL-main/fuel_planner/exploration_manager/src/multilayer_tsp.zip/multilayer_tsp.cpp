/****************This is main part of AELB******************/
#include <exploration_manager/fast_exploration_manager.h>
#include <thread>
#include <iostream>
#include <fstream>
#include <lkh_tsp_solver/lkh_interface.h>
#include <active_perception/graph_node.h>
#include <active_perception/graph_search.h>
#include <active_perception/perception_utils.h>
#include <plan_env/raycast.h>
#include <plan_env/sdf_map.h>
#include <plan_env/edt_environment.h>
#include <active_perception/frontier_finder.h>
#include <plan_manage/planner_manager.h>
#include <exploration_manager/multilayer_tsp.h>

#include <exploration_manager/expl_data.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <visualization_msgs/Marker.h>

using namespace Eigen;

namespace fast_planner{

//构造函数
Multilayer::Multilayer(){
    isFirstExplore = true;
    map_size_min << 0, 0, 0;
    map_size_max << 0, 0, 0;
}

//析构函数
Multilayer::~Multilayer(){
    ViewNode::astar_.reset();
    ViewNode::caster_.reset();
    ViewNode::map_.reset();
}

//初始化参数与相关类
void Multilayer::initialize(ros::NodeHandle& nh){
    planner_manager_.reset(new FastPlannerManager);
    planner_manager_->initPlanModules(nh);
    edt_environment_ = planner_manager_->edt_environment_;
    sdf_map_ = edt_environment_->sdf_map_;
    frontier_finder_.reset(new FrontierFinder(edt_environment_, nh));

    ed_.reset(new ExplorationData);
    ep_.reset(new ExplorationParam);

    nh.param("exploration/refine_local", ep_->refine_local_, true);
    nh.param("exploration/refined_num", ep_->refined_num_, -1);
    nh.param("exploration/refined_radius", ep_->refined_radius_, -1.0);
    nh.param("exploration/top_view_num", ep_->top_view_num_, -1);
    nh.param("exploration/max_decay", ep_->max_decay_, -1.0);
    nh.param("exploration/tsp_dir", ep_->tsp_dir_, string("null"));
    nh.param("exploration/relax_time", ep_->relax_time_, 1.0);

    nh.param("exploration/vm", ViewNode::vm_, -1.0);
    nh.param("exploration/am", ViewNode::am_, -1.0);
    nh.param("exploration/yd", ViewNode::yd_, -1.0);
    nh.param("exploration/ydd", ViewNode::ydd_, -1.0);
    nh.param("exploration/w_dir", ViewNode::w_dir_, -1.0);

    ViewNode::astar_.reset(new Astar);
    ViewNode::astar_->init(nh, edt_environment_);
    ViewNode::map_ = sdf_map_;

    double resolution_ = sdf_map_->getResolution();
    Eigen::Vector3d origin, size;
    sdf_map_->getRegion(origin, size);
    ViewNode::caster_.reset(new RayCaster);
    ViewNode::caster_->setParams(resolution_, origin);

    planner_manager_->path_finder_->lambda_heu_ = 1.0;
    // planner_manager_->path_finder_->max_search_time_ = 0.05;
    planner_manager_->path_finder_->max_search_time_ = 1.0;

    // Initialize TSP par file
    ofstream par_file(ep_->tsp_dir_ + "/single.par");
    par_file << "PROBLEM_FILE = " << ep_->tsp_dir_ << "/single.tsp\n";
    par_file << "GAIN23 = NO\n";
    par_file << "OUTPUT_TOUR_FILE =" << ep_->tsp_dir_ << "/single.txt\n";
    par_file << "RUNS = 1\n";

}

//双层TSP序列处理函数
int Multilayer::Multilayer_manager(const Vector3d& pos, const Vector3d& vel, const Vector3d& acc,
                        const Vector3d& yaw){
    //记录当前时间信息
    ros::Time t1 = ros::Time::now();
    auto t2 = t1;

    //清空视图存储与全局视点信息
    ed_->views_.clear();
    ed_->global_tour_.clear();
    std::cout << "start pos: " << pos.transpose() << ", vel: " << vel.transpose()
            << ", acc: " << acc.transpose() << std::endl;

    //更新边界点信息
    frontier_finder_->searchFrontiers();

    //记录获取前沿的时间
    double frontier_time = (ros::Time::now() - t1).toSec();
    t1 = ros::Time::now();

    //将前沿、前沿box、休眠前沿的信息记录在数据结构中
    frontier_finder_->computeFrontiersToVisit();
    frontier_finder_->getFrontiers(ed_->frontiers_);
    frontier_finder_->getFrontierBoxes(ed_->frontier_boxes_);
    frontier_finder_->getDormantFrontiers(ed_->dead_frontiers_);
    
    //没有前沿信息，即探索结束，逻辑在上一层
    if (ed_->frontiers_.empty()) {
        ROS_WARN("No coverable frontier.");
        return NO_FRONTIER;
    }



    //获取当前无人机位置
    GetPosition(p_cur);
    //判断是否为初始探索状态
    if(isFirstExplore == true){
        //读取当前地图信息更新地图尺寸
        GetMapSize(map_size_min,map_size_max);
        //高度分割
        Hightsplite(map_size_min,map_size_max,r_hsplite);
        //根据当前位置选择合适的探索高度
        ChooseStarR(p_cur,r_hsplite);
        //标志位置0
        isFirstExplore = false;
    }
    //判断当前区域的是否有未知边界
    if(view_cur_region.size() == 0){
        //判断当前水平列表是否为空
        if(r_lsplite.size() == 0){
            //判断高度序列是否为空
            if(r_hsplite.size() == 0){
                //探索完三维空间中的所有边界，即探索完成
                return SUCCEED;
            }
            else{
                //高度序列不为空，读取高度序列并分割区域
                Levelsplite(r_hsplite,r_lsplite);
                //外部TSP保证探索区域规划的合理性
                ExternalTsp(p_cur,r_lsplite,r_hsplite);
            }
        }
        else{
            //当前水平列表不为空，生成筛选当前区域的边界视点
            UpdateRegionViewPoint(r_lsplite,view_cur_region);
        }
    }
    //当前区域视点不为空，直接对其进行规划
    else{
        InternalTsp(p_cur,view_cur_region,r_lsplite);
    }
}

/**********读取无人机当前位置************/
/*
输出：无人机位置
*/
void Multilayer::GetPosition(Vector3d& p_cur_){

}

/**********更新地图区域信息************/
/*
输出：地图区域信息
*/
void Multilayer::GetMapSize(const Vector3d& map_size_min_, const Vector3d& map_size_max_){

}

/**********更新探索高度序列************/
/*
功能：
1. 根据p_cur_对高度序列进行排序
*/
void Multilayer::ChooseStarR(Vector3d& p_cur_, vector<Region>& r_hsplite_){

}

/**********分割高度序列函数************/
/*
功能：
1. 根据分辨率信息在高度上分割空间，将其输出为不同高度的TSP高度序列vector<Region>& r_hsplite
*/
void Multilayer::Hightsplite(const Vector3d& map_min_, const Vector3d& map_max_, vector<Region>& r_hsplite_){

}

/**********分割水平空间序列函数************/
/*
功能：
1. 读取r_hsplite_序列中的第一个元素
2. 对弹出的空间进行水平分割得到r_lsplite_
3. 弹出r_hsplite_序列中的第一个元素
*/
void Multilayer::Levelsplite(vector<Region>& r_hsplite_, vector<Region>& r_lsplite_){

}

/**********视点判断函数************/
/*
功能：
1. 读取所有边界视点信息
2. 读取当前区域的空间
3. 将在当前空间内的视点加入到当前区域视点序列
*/
void Multilayer::UpdateRegionViewPoint(vector<Region>& r_lsplite_, vector<Vector3d>& view_cur_region_){

}

/**********外部区域TSP函数************/
/*
功能：
1. 将当前位置、区域空间放入到TSP序列中
2. 判断r_hsplite_是否为空，不为空时将第一个加入当前优化序列，为空时不加入优化序列
3. 调用TSP优化算法
*/
void Multilayer::ExternalTsp(const Vector3d& p_cur_, const vector<Region>& r_lsplite_, vector<Region>& r_hsplite_){

}

/**********内部区域TSP函数************/
/*
功能：
1. 将当前位置、区域视点放入到TSP序列中
2. 判断r_lsplite_是否为空，不为空时将第一个加入当前优化序列，为空时不加入优化序列
3. 调用TSP优化算法
*/
void Multilayer::InternalTsp(const Vector3d& p_cur_, const vector<Vector3d>& view_cur_region_, vector<Region>& r_lsplite_){

}

}