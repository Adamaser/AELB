/****************This is main part of AELB******************/
#ifndef _MULTILAYER_TSP_H_
#define _MULTILAYER_TSP_H_

#include <ros/ros.h>
#include <Eigen/Eigen>
#include <memory>
#include <vector>

using std::vector;
using Eigen::Vector3d;
using std::shared_ptr;
using std::unique_ptr;

namespace fast_planner{
class EDTEnvironment;
class SDFMap;
class FastPlannerManager;
class FrontierFinder;
struct ExplorationParam;
struct ExplorationData;

enum EXPL_RESULT { NO_FRONTIER, FAIL, SUCCEED };

//探索区域结构体
struct Region{
    //Regional scope and center
    Vector3d region_min;
    Vector3d region_max;
    Vector3d region_center;
};

class Multilayer{
private:
    shared_ptr<EDTEnvironment> edt_environment_;
    shared_ptr<SDFMap> sdf_map_;

    //size of map
    Vector3d map_size_min, map_size_max;
    //splite region in height、level
    vector<Region> r_hsplite,r_lsplite;
    //the view_point in current region、current position
    vector<Vector3d> view_cur_region;
    Vector3d p_cur;
    //record curren region
    Region R_now, R_next;
    //the first time beginning exploration
    bool isFirstExplore; 

    //update current position
    void GetPosition(Vector3d& p_cur_);
    //get map size
    void GetMapSize(const Vector3d& map_size_min_, const Vector3d& map_size_max_);
    //choose most suitable R_hnow
    void ChooseStarR(Vector3d& p_cur_, vector<Region>& r_hsplite_);
    //splite the region in height
    void Hightsplite(const Vector3d& map_min_, const Vector3d& map_max_, vector<Region>& r_hsplite_);
    //splite the region in the same level
    void Levelsplite(vector<Region>& r_hsplite_, vector<Region>& r_lsplite_);
    //get view point in current region
    void UpdateRegionViewPoint(vector<Region>& r_lsplite_, vector<Vector3d>& view_cur_region_);
    //external TSP solver
    void ExternalTsp(const Vector3d& p_cur_, const vector<Region>& r_lsplite_, vector<Region>& r_hsplite_);
    //internal TSP solver
    void InternalTsp(const Vector3d& p_cur_, const vector<Vector3d>& view_cur_region_, vector<Region>& r_lsplite_);
public:
    typedef shared_ptr<FastExplorationManager> Ptr;

    shared_ptr<ExplorationData> ed_;
    shared_ptr<ExplorationParam> ep_;
    shared_ptr<FastPlannerManager> planner_manager_;
    shared_ptr<FrontierFinder> frontier_finder_;

    //Constructors, Destructors
    Multilayer();
    ~Multilayer();

    //initial
    void initialize(ros::NodeHandle& nh);

    //planner manager
    int Multilayer_manager(const Vector3d& pos, const Vector3d& vel, const Vector3d& acc,
                        const Vector3d& yaw);

};

}


#endif